# CSS Grid | Poster

A Pen created on CodePen.io. Original URL: [https://codepen.io/BurmesePotato/pen/WNrBWmE](https://codepen.io/BurmesePotato/pen/WNrBWmE).

